Set WshShell = CreateObject("WScript.Shell")
strPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

edge1 = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe")
edge2 = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")
chrome1 = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\Google\Chrome\Application\chrome.exe")
chrome2 = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe")

Set fso = CreateObject("Scripting.FileSystemObject")
url = "file:///" & Replace(strPath, "\", "/") & "/index.html"

If fso.FileExists(edge1) Then
    WshShell.Run """" & edge1 & """ --app=""" & url & """", 1, False
ElseIf fso.FileExists(edge2) Then
    WshShell.Run """" & edge2 & """ --app=""" & url & """", 1, False
ElseIf fso.FileExists(chrome1) Then
    WshShell.Run """" & chrome1 & """ --app=""" & url & """", 1, False
ElseIf fso.FileExists(chrome2) Then
    WshShell.Run """" & chrome2 & """ --app=""" & url & """", 1, False
Else
    WshShell.Run "explorer.exe """ & url & """", 1, False
End If
