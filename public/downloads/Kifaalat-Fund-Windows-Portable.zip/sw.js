/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "1c1f439ce8cc777b93162a341162161c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b5b9a643dbaaeb6b9f727d82bc7b114f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "5d7be2ec028400e5d24dbf747462531a"
  }, {
    "url": "index.html",
    "revision": "2869fdefd93a06a16438112836ee882b"
  }, {
    "url": "icon.svg",
    "revision": "8529b6b81c8a662a5e5ba196be9e1dfe"
  }, {
    "url": "favicon.ico",
    "revision": "1e5d25d0be0784da4c7f84ae326937c6"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "41a1700ebc2da7ceb871cc1395b6d33b"
  }, {
    "url": "downloads/Kifaalat-Fund-Standalone-Offline.html",
    "revision": "4b261fc50b755978d7aebbc1de6107c0"
  }, {
    "url": "assets/purify.es-BZxk_wWO.js",
    "revision": null
  }, {
    "url": "assets/jspdf.es.min-qq4cKIJO.js",
    "revision": null
  }, {
    "url": "assets/index.es-CFiQMxH8.js",
    "revision": null
  }, {
    "url": "assets/index-DbJv1HU9.css",
    "revision": null
  }, {
    "url": "assets/index-BY7_6UCh.js",
    "revision": null
  }, {
    "url": "assets/html2canvas-C7lcJNla.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "41a1700ebc2da7ceb871cc1395b6d33b"
  }, {
    "url": "icon.svg",
    "revision": "8529b6b81c8a662a5e5ba196be9e1dfe"
  }, {
    "url": "pwa-192x192.png",
    "revision": "5d7be2ec028400e5d24dbf747462531a"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b5b9a643dbaaeb6b9f727d82bc7b114f"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "1c1f439ce8cc777b93162a341162161c"
  }, {
    "url": "manifest.webmanifest",
    "revision": "f36d78f654881bff6f602041d7acf7c2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
