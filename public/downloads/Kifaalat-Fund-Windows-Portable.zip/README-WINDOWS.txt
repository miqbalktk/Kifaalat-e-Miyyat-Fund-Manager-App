=============================================================
  KIFAALAT E MIYYAT FUND - PORTABLE DESKTOP APPLICATION
  کفالت میت فنڈ - پورٹیبل ڈیسک ٹاپ سافٹ ویئر (بغیر انسٹالیشن)
=============================================================

[URDU GUIDE - اردو ہدایات]
1. اس زپ فائل کو اپنے کمپیوٹر یا یو ایس بی (USB Flash Drive) میں Extract (ان زپ) کریں۔
2. چلانے کے لیے 'Kifaalat-Fund.bat' یا بغیر بلیک اسکرین کے 'Kifaalat-Fund-Silent.vbs' پر ڈبل کلک کریں۔
3. یہ سافٹ ویئر بغیر کسی انسٹالیشن اور بغیر انٹرنیٹ کے 100% آف لائن چلتا ہے۔
4. تمام ممبران، فنڈ بیلنس، ادائیگیاں، اور رسیدیں آپ کے کمپیوٹر میں محفوظ رہتی ہیں۔
5. کسی ایڈمنسٹریٹر پرمشن کی ضرورت نہیں ہے۔ یہ ونڈوز 7، 8، 10 اور 11 پر بغیر کسی پابندی کے چلتا ہے۔

[ENGLISH GUIDE]
1. Extract this ZIP file to any folder on your PC or USB flash drive.
2. Double-click 'Kifaalat-Fund.bat' (or 'Kifaalat-Fund-Silent.vbs').
3. Runs immediately in a dedicated desktop window without address bars.
4. Requires NO installation and works 100% offline without internet.
5. Fully compatible with Windows 7, 8, 8.1, 10, and 11 (32-bit & 64-bit).

رابطہ: محمد اقبال خٹک (خزانچی و فنانس سیکرٹری) - 0346-9100998
=============================================================
